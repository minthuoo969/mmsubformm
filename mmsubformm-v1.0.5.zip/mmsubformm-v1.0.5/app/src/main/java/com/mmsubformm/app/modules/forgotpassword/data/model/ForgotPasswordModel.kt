package com.mmsubformm.app.modules.forgotpassword.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class ForgotPasswordModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtForgotPassword: String? =
      MyApp.getInstance().resources.getString(R.string.msg_forgot_password)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtYouforgotyour: String? =
      MyApp.getInstance().resources.getString(R.string.msg_you_forgot_your)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etEmailaddressValue: String? = null
)
