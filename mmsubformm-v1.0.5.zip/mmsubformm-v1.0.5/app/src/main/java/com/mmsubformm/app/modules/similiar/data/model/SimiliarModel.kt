package com.mmsubformm.app.modules.similiar.`data`.model

class SimiliarModel()
