package com.mmsubformm.app.modules.subscribepopup.ui

import android.content.Context
import androidx.fragment.app.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseDialogFragment
import com.mmsubformm.app.databinding.DialogSubscribePopupBinding
import com.mmsubformm.app.modules.chooseplan.ui.ChoosePlanActivity
import com.mmsubformm.app.modules.subscribepopup.`data`.viewmodel.SubscribePopupVM
import kotlin.String
import kotlin.Unit

class SubscribePopupDialog :
    BaseDialogFragment<DialogSubscribePopupBinding>(R.layout.dialog_subscribe_popup) {
  private val viewModel: SubscribePopupVM by viewModels<SubscribePopupVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    binding.subscribePopupVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnSubscribe.setOnClickListener {
      val destIntent = ChoosePlanActivity.getIntent(requireActivity(), null)
      startActivity(destIntent)
      dismiss()
    }
  }

  companion object {
    const val TAG: String = "SUBSCRIBE_POPUP_DIALOG"

  }
}
