package com.mmsubformm.app.modules.downloadedtabcontainer.ui

import android.os.Bundle
import androidx.fragment.app.viewModels
import com.google.android.material.tabs.TabLayoutMediator
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseFragment
import com.mmsubformm.app.databinding.FragmentDownloadedTabContainerBinding
import com.mmsubformm.app.modules.downloadedtabcontainer.`data`.viewmodel.DownloadedTabContainerVM
import kotlin.String
import kotlin.Unit

class DownloadedTabContainerFragment :
    BaseFragment<FragmentDownloadedTabContainerBinding>(R.layout.fragment_downloaded_tab_container)
    {
  private val viewModel: DownloadedTabContainerVM by viewModels<DownloadedTabContainerVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    binding.downloadedTabContainerVM = viewModel
    val adapter = DownloadedTabContainerFragmentPagerAdapter(childFragmentManager,lifecycle)
    binding.viewPagerTabbarview.adapter = adapter
    TabLayoutMediator(binding.tabLayoutTab,binding.viewPagerTabbarview) { tab, position ->
      tab.text = DownloadedTabContainerFragmentPagerAdapter.title[position]
      }.attach()
    }

    override fun setUpClicks(): Unit {
    }

    companion object {
      const val TAG: String = "DOWNLOADED_TAB_CONTAINER_FRAGMENT"


      fun getInstance(bundle: Bundle?): DownloadedTabContainerFragment {
        val fragment = DownloadedTabContainerFragment()
        fragment.arguments = bundle
        return fragment
      }
    }
  }
