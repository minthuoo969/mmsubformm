package com.mmsubformm.app.modules.resetpasswordsuccess.ui

import androidx.activity.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseActivity
import com.mmsubformm.app.databinding.ActivityResetPasswordSuccessBinding
import com.mmsubformm.app.modules.resetpasswordsuccess.`data`.viewmodel.ResetPasswordSuccessVM
import kotlin.String
import kotlin.Unit

class ResetPasswordSuccessActivity :
    BaseActivity<ActivityResetPasswordSuccessBinding>(R.layout.activity_reset_password_success) {
  private val viewModel: ResetPasswordSuccessVM by viewModels<ResetPasswordSuccessVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.resetPasswordSuccessVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "RESET_PASSWORD_SUCCESS_ACTIVITY"

  }
}
