package com.mmsubformm.app.modules.homerecentlywatched.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.viewbinding.ViewBinding
import com.asksira.loopingviewpager.LoopingPagerAdapter
import com.mmsubformm.app.databinding.SlideritemHomeRecentlyWatched1Binding
import com.mmsubformm.app.modules.homerecentlywatched.`data`.model.ImageSliderSliderrectangletenModel
import java.util.ArrayList
import kotlin.Boolean
import kotlin.Int

class SliderrectangletenAdapter(
  val dataList: ArrayList<ImageSliderSliderrectangletenModel>,
  val mIsInfinite: Boolean
) : LoopingPagerAdapter<ImageSliderSliderrectangletenModel>(dataList, mIsInfinite) {
  override fun bindView(
    binding: ViewBinding,
    listPosition: Int,
    viewType: Int
  ) {
    if (binding is SlideritemHomeRecentlyWatched1Binding) {
      binding.imageSliderSliderrectangletenModel = dataList[listPosition]
    }
  }

  override fun inflateView(
    viewType: Int,
    container: ViewGroup,
    listPosition: Int
  ): ViewBinding {
    val itemBinding =  SlideritemHomeRecentlyWatched1Binding.inflate(
    LayoutInflater.from(container.context),
                    container,
                    false
    )
    return itemBinding
  }
}
