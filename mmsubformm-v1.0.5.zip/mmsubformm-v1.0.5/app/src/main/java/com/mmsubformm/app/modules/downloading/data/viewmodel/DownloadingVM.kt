package com.mmsubformm.app.modules.downloading.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmsubformm.app.modules.downloading.`data`.model.DownloadingModel
import com.mmsubformm.app.modules.downloading.`data`.model.DownloadingRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class DownloadingVM : ViewModel(), KoinComponent {
  val downloadingModel: MutableLiveData<DownloadingModel> = MutableLiveData(DownloadingModel())

  var navArguments: Bundle? = null

  val downloadingList: MutableLiveData<MutableList<DownloadingRowModel>> =
      MutableLiveData(mutableListOf())
}
