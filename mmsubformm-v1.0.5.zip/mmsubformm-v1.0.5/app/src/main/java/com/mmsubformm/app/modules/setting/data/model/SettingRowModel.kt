package com.mmsubformm.app.modules.setting.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class SettingRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtType: String? = MyApp.getInstance().resources.getString(R.string.lbl_notification)

)
