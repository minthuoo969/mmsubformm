package com.mmsubformm.app.modules.emptystatedownloading.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class EmptyStateDownloadingModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtNovideostodownload: String? =
      MyApp.getInstance().resources.getString(R.string.msg_no_videos_to_do)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLetsfindanddownload: String? =
      MyApp.getInstance().resources.getString(R.string.msg_let_s_find_and)

)
