package com.mmsubformm.app.modules.deletefromsaved.ui

import android.content.Context
import androidx.fragment.app.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseDialogFragment
import com.mmsubformm.app.databinding.DialogDeleteFromSavedBinding
import com.mmsubformm.app.modules.deletefromsaved.`data`.viewmodel.DeleteFromSavedVM
import kotlin.String
import kotlin.Unit

class DeleteFromSavedDialog :
    BaseDialogFragment<DialogDeleteFromSavedBinding>(R.layout.dialog_delete_from_saved) {
  private val viewModel: DeleteFromSavedVM by viewModels<DeleteFromSavedVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    binding.deleteFromSavedVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "DELETE_FROM_SAVED_DIALOG"

  }
}
