package com.mmsubformm.app.modules.search.`data`.model

class ListRowModel()
