package com.mmsubformm.app.modules.subscribepopup.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class SubscribePopupModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtBeapremiumuser: String? =
      MyApp.getInstance().resources.getString(R.string.msg_be_a_premium_us)

)
