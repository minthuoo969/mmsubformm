package com.mmsubformm.app.modules.deletepopup.ui

import android.content.Context
import androidx.fragment.app.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseDialogFragment
import com.mmsubformm.app.databinding.DialogDeletePopupBinding
import com.mmsubformm.app.modules.deletepopup.`data`.viewmodel.DeletePopupVM
import kotlin.String
import kotlin.Unit

class DeletePopupDialog : BaseDialogFragment<DialogDeletePopupBinding>(R.layout.dialog_delete_popup)
    {
  private val viewModel: DeletePopupVM by viewModels<DeletePopupVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    binding.deletePopupVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "DELETE_POPUP_DIALOG"

  }
}
