package com.mmsubformm.app.modules.home.ui

import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseFragment
import com.mmsubformm.app.databinding.FragmentHomeBinding
import com.mmsubformm.app.modules.episodetabcontainer.ui.EpisodeTabContainerActivity
import com.mmsubformm.app.modules.home.`data`.model.ImageSliderSlidergroup427319005Model
import com.mmsubformm.app.modules.home.`data`.model.ListallRowModel
import com.mmsubformm.app.modules.home.`data`.model.ListrectangleRowModel
import com.mmsubformm.app.modules.home.`data`.model.ListrectanglefiveRowModel
import com.mmsubformm.app.modules.home.`data`.viewmodel.HomeVM
import kotlin.Int
import kotlin.String
import kotlin.Unit
import kotlin.collections.ArrayList

class HomeFragment : BaseFragment<FragmentHomeBinding>(R.layout.fragment_home) {
  private val imageUri: Uri =
      Uri.parse("android.resource://com.mmsubformm.app/drawable/img_image6_297x375_1")


  private val imageSliderSlidergroup427319005Items: ArrayList<ImageSliderSlidergroup427319005Model>
      = arrayListOf(ImageSliderSlidergroup427319005Model(imageImageSix =
  imageUri.toString()),ImageSliderSlidergroup427319005Model(imageImageSix =
  imageUri.toString()))


  private val viewModel: HomeVM by viewModels<HomeVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    val slidergroup427319005Adapter =
    Slidergroup427319005Adapter(imageSliderSlidergroup427319005Items,true)
    binding.imageSliderSlidergroup427319005.adapter = slidergroup427319005Adapter
    val listallAdapter = ListallAdapter(viewModel.listallList.value?:mutableListOf())
    binding.recyclerListall.adapter = listallAdapter
    listallAdapter.setOnItemClickListener(
    object : ListallAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListallRowModel) {
        onClickRecyclerListall(view, position, item)
      }
    }
    )
    viewModel.listallList.observe(requireActivity()) {
      listallAdapter.updateData(it)
    }
    val listrectangleAdapter =
    ListrectangleAdapter(viewModel.listrectangleList.value?:mutableListOf())
    binding.recyclerListrectangle.adapter = listrectangleAdapter
    listrectangleAdapter.setOnItemClickListener(
    object : ListrectangleAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListrectangleRowModel) {
        onClickRecyclerListrectangle(view, position, item)
      }
    }
    )
    viewModel.listrectangleList.observe(requireActivity()) {
      listrectangleAdapter.updateData(it)
    }
    val listrectanglefiveAdapter =
    ListrectanglefiveAdapter(viewModel.listrectanglefiveList.value?:mutableListOf())
    binding.recyclerListrectanglefive.adapter = listrectanglefiveAdapter
    listrectanglefiveAdapter.setOnItemClickListener(
    object : ListrectanglefiveAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListrectanglefiveRowModel) {
        onClickRecyclerListrectanglefive(view, position, item)
      }
    }
    )
    viewModel.listrectanglefiveList.observe(requireActivity()) {
      listrectanglefiveAdapter.updateData(it)
    }
    binding.homeVM = viewModel
  }

  override fun onPause(): Unit {
    binding.imageSliderSlidergroup427319005.pauseAutoScroll()
    super.onPause()
  }

  override fun onResume(): Unit {
    super.onResume()
    binding.imageSliderSlidergroup427319005.resumeAutoScroll()
  }

  override fun setUpClicks(): Unit {
  }

  fun onClickRecyclerListall(
    view: View,
    position: Int,
    item: ListallRowModel
  ): Unit {
    when(view.id) {
    }
  }

  fun onClickRecyclerListrectangle(
    view: View,
    position: Int,
    item: ListrectangleRowModel
  ): Unit {
    when(view.id) {
      R.id.imageRectangle -> {
        val destIntent = EpisodeTabContainerActivity.getIntent(requireActivity(), null)
        startActivity(destIntent)
        requireActivity().onBackPressed()
      }
    }
  }

  fun onClickRecyclerListrectanglefive(
    view: View,
    position: Int,
    item: ListrectanglefiveRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "HOME_FRAGMENT"


    fun getInstance(bundle: Bundle?): HomeFragment {
      val fragment = HomeFragment()
      fragment.arguments = bundle
      return fragment
    }
  }
}
