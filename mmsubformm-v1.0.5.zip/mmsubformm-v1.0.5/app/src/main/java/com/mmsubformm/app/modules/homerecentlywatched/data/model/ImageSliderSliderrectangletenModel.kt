package com.mmsubformm.app.modules.homerecentlywatched.`data`.model

import kotlin.String

data class ImageSliderSliderrectangletenModel(
  /**
   * TODO Replace with dynamic value
   */
  var imageImageSix: String? = ""

)
