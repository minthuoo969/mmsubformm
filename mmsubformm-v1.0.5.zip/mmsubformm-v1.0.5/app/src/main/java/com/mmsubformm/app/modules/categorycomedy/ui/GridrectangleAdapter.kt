package com.mmsubformm.app.modules.categorycomedy.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mmsubformm.app.R
import com.mmsubformm.app.databinding.RowGridrectangleBinding
import com.mmsubformm.app.modules.categorycomedy.`data`.model.GridrectangleRowModel
import kotlin.Int
import kotlin.collections.List

class GridrectangleAdapter(
  var list: List<GridrectangleRowModel>
) : RecyclerView.Adapter<GridrectangleAdapter.RowGridrectangleVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowGridrectangleVH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_gridrectangle,parent,false)
    return RowGridrectangleVH(view)
  }

  override fun onBindViewHolder(holder: RowGridrectangleVH, position: Int) {
    val gridrectangleRowModel = GridrectangleRowModel()
    // TODO uncomment following line after integration with data source
    // val gridrectangleRowModel = list[position]
    holder.binding.gridrectangleRowModel = gridrectangleRowModel
  }

  override fun getItemCount(): Int = 12
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<GridrectangleRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: GridrectangleRowModel
    ) {
    }
  }

  inner class RowGridrectangleVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowGridrectangleBinding = RowGridrectangleBinding.bind(itemView)
  }
}
