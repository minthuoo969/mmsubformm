package com.mmsubformm.app.modules.home.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mmsubformm.app.R
import com.mmsubformm.app.databinding.RowListallBinding
import com.mmsubformm.app.modules.home.`data`.model.ListallRowModel
import kotlin.Int
import kotlin.collections.List

class ListallAdapter(
  var list: List<ListallRowModel>
) : RecyclerView.Adapter<ListallAdapter.RowListallVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowListallVH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_listall,parent,false)
    return RowListallVH(view)
  }

  override fun onBindViewHolder(holder: RowListallVH, position: Int) {
    val listallRowModel = ListallRowModel()
    // TODO uncomment following line after integration with data source
    // val listallRowModel = list[position]
    holder.binding.listallRowModel = listallRowModel
  }

  override fun getItemCount(): Int = 5
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<ListallRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: ListallRowModel
    ) {
    }
  }

  inner class RowListallVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowListallBinding = RowListallBinding.bind(itemView)
  }
}
