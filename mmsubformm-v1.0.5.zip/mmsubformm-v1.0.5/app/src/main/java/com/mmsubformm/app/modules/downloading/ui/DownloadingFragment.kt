package com.mmsubformm.app.modules.downloading.ui

import android.view.View
import androidx.fragment.app.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseFragment
import com.mmsubformm.app.databinding.FragmentDownloadingBinding
import com.mmsubformm.app.modules.downloading.`data`.model.DownloadingRowModel
import com.mmsubformm.app.modules.downloading.`data`.viewmodel.DownloadingVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class DownloadingFragment : BaseFragment<FragmentDownloadingBinding>(R.layout.fragment_downloading)
    {
  private val viewModel: DownloadingVM by viewModels<DownloadingVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    val downloadingAdapter =
    DownloadingAdapter(viewModel.downloadingList.value?:mutableListOf())
    binding.recyclerDownloading.adapter = downloadingAdapter
    downloadingAdapter.setOnItemClickListener(
    object : DownloadingAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : DownloadingRowModel) {
        onClickRecyclerDownloading(view, position, item)
      }
    }
    )
    viewModel.downloadingList.observe(requireActivity()) {
      downloadingAdapter.updateData(it)
    }
    binding.downloadingVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  fun onClickRecyclerDownloading(
    view: View,
    position: Int,
    item: DownloadingRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "DOWNLOADING_FRAGMENT"

  }
}
