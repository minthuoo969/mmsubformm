package com.mmsubformm.app.appcomponents.network

/**
 * object class which contains the API response Contents
 */
object ResponseCode {
    const val OK = 200
}