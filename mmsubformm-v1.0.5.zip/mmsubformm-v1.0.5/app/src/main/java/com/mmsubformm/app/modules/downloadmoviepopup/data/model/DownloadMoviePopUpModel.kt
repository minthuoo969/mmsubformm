package com.mmsubformm.app.modules.downloadmoviepopup.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class DownloadMoviePopUpModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtDownloadFile: String? = MyApp.getInstance().resources.getString(R.string.lbl_download_file)

)
