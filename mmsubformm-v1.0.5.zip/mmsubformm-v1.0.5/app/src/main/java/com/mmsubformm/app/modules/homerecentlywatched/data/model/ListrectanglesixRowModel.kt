package com.mmsubformm.app.modules.homerecentlywatched.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class ListrectanglesixRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_doctor_strange)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRuntime: String? = MyApp.getInstance().resources.getString(R.string.lbl_1_50_35)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtZipcode: String? = MyApp.getInstance().resources.getString(R.string.lbl_2021)

)
