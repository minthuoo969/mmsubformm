package com.mmsubformm.app.modules.searchhelp.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmsubformm.app.modules.searchhelp.`data`.model.SearchHelpModel
import org.koin.core.KoinComponent

class SearchHelpVM : ViewModel(), KoinComponent {
  val searchHelpModel: MutableLiveData<SearchHelpModel> = MutableLiveData(SearchHelpModel())

  var navArguments: Bundle? = null
}
