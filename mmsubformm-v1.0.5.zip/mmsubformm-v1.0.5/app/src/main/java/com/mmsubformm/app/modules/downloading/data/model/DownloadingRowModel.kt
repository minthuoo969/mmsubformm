package com.mmsubformm.app.modules.downloading.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class DownloadingRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtTitle: String? = MyApp.getInstance().resources.getString(R.string.msg_captain_america2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDownloadspeed: String? = MyApp.getInstance().resources.getString(R.string.lbl_720k_s)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFilesize: String? = MyApp.getInstance().resources.getString(R.string.lbl_250mb_1_5gb)

)
