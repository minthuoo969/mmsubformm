package com.mmsubformm.app.modules.otpverification.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class OtpVerificationModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtOTPVerificationOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_otp_verificatio)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_6_digit_code_has3)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDidntreceivetheOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_didn_t_receive2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtResend: String? = MyApp.getInstance().resources.getString(R.string.lbl_resend)

)
