package com.mmsubformm.app.modules.paymentsuccesfulpopup.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmsubformm.app.modules.paymentsuccesfulpopup.`data`.model.PaymentSuccesfulPopupModel
import org.koin.core.KoinComponent

class PaymentSuccesfulPopupVM : ViewModel(), KoinComponent {
  val paymentSuccesfulPopupModel: MutableLiveData<PaymentSuccesfulPopupModel> =
      MutableLiveData(PaymentSuccesfulPopupModel())

  var navArguments: Bundle? = null
}
