package com.mmsubformm.app.modules.chooseplan.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmsubformm.app.modules.chooseplan.`data`.model.ChoosePlanModel
import com.mmsubformm.app.modules.chooseplan.`data`.model.ChooseplanRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class ChoosePlanVM : ViewModel(), KoinComponent {
  val choosePlanModel: MutableLiveData<ChoosePlanModel> = MutableLiveData(ChoosePlanModel())

  var navArguments: Bundle? = null

  val chooseplanList: MutableLiveData<MutableList<ChooseplanRowModel>> =
      MutableLiveData(mutableListOf())
}
