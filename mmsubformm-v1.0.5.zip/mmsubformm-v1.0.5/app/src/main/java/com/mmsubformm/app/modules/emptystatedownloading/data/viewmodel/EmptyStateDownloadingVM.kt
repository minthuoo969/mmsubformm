package com.mmsubformm.app.modules.emptystatedownloading.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmsubformm.app.modules.emptystatedownloading.`data`.model.EmptyStateDownloadingModel
import org.koin.core.KoinComponent

class EmptyStateDownloadingVM : ViewModel(), KoinComponent {
  val emptyStateDownloadingModel: MutableLiveData<EmptyStateDownloadingModel> =
      MutableLiveData(EmptyStateDownloadingModel())

  var navArguments: Bundle? = null
}
