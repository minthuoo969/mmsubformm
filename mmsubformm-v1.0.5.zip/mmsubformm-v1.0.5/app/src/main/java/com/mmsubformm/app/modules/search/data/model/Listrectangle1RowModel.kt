package com.mmsubformm.app.modules.search.`data`.model

class Listrectangle1RowModel()
