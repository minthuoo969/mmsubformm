package com.mmsubformm.app.modules.home.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mmsubformm.app.R
import com.mmsubformm.app.databinding.RowListrectanglefiveBinding
import com.mmsubformm.app.modules.home.`data`.model.ListrectanglefiveRowModel
import kotlin.Int
import kotlin.collections.List

class ListrectanglefiveAdapter(
  var list: List<ListrectanglefiveRowModel>
) : RecyclerView.Adapter<ListrectanglefiveAdapter.RowListrectanglefiveVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowListrectanglefiveVH {
    val
        view=LayoutInflater.from(parent.context).inflate(R.layout.row_listrectanglefive,parent,false)
    return RowListrectanglefiveVH(view)
  }

  override fun onBindViewHolder(holder: RowListrectanglefiveVH, position: Int) {
    val listrectanglefiveRowModel = ListrectanglefiveRowModel()
    // TODO uncomment following line after integration with data source
    // val listrectanglefiveRowModel = list[position]
    holder.binding.listrectanglefiveRowModel = listrectanglefiveRowModel
  }

  override fun getItemCount(): Int = 3
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<ListrectanglefiveRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: ListrectanglefiveRowModel
    ) {
    }
  }

  inner class RowListrectanglefiveVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowListrectanglefiveBinding = RowListrectanglefiveBinding.bind(itemView)
  }
}
