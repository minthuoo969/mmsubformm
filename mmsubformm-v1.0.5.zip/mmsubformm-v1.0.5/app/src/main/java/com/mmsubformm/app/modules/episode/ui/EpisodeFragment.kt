package com.mmsubformm.app.modules.episode.ui

import androidx.fragment.app.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseFragment
import com.mmsubformm.app.databinding.FragmentEpisodeBinding
import com.mmsubformm.app.modules.episode.`data`.viewmodel.EpisodeVM
import kotlin.String
import kotlin.Unit

class EpisodeFragment : BaseFragment<FragmentEpisodeBinding>(R.layout.fragment_episode) {
  private val viewModel: EpisodeVM by viewModels<EpisodeVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    binding.episodeVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "EPISODE_FRAGMENT"

  }
}
