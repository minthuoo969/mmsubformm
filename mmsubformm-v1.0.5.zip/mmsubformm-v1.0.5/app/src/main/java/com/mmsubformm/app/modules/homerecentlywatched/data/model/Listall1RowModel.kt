package com.mmsubformm.app.modules.homerecentlywatched.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class Listall1RowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtAll: String? = MyApp.getInstance().resources.getString(R.string.lbl_all)

)
