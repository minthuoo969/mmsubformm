package com.mmsubformm.app.modules.chooseplan.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseActivity
import com.mmsubformm.app.databinding.ActivityChoosePlanBinding
import com.mmsubformm.app.modules.chooseplan.`data`.model.ChooseplanRowModel
import com.mmsubformm.app.modules.chooseplan.`data`.viewmodel.ChoosePlanVM
import com.mmsubformm.app.modules.paymentmethod.ui.PaymentMethodActivity
import kotlin.Int
import kotlin.String
import kotlin.Unit

class ChoosePlanActivity : BaseActivity<ActivityChoosePlanBinding>(R.layout.activity_choose_plan) {
  private val viewModel: ChoosePlanVM by viewModels<ChoosePlanVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val chooseplanAdapter = ChooseplanAdapter(viewModel.chooseplanList.value?:mutableListOf())
    binding.recyclerChooseplan.adapter = chooseplanAdapter
    chooseplanAdapter.setOnItemClickListener(
    object : ChooseplanAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ChooseplanRowModel) {
        onClickRecyclerChooseplan(view, position, item)
      }
    }
    )
    viewModel.chooseplanList.observe(this) {
      chooseplanAdapter.updateData(it)
    }
    binding.choosePlanVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnClose.setOnClickListener {
      finish()
    }
  }

  fun onClickRecyclerChooseplan(
    view: View,
    position: Int,
    item: ChooseplanRowModel
  ): Unit {
    when(view.id) {
      R.id.btnSubscribeplan ->  {
        val destIntent = PaymentMethodActivity.getIntent(this, null)
        startActivity(destIntent)
      }
    }
  }

  companion object {
    const val TAG: String = "CHOOSE_PLAN_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, ChoosePlanActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
