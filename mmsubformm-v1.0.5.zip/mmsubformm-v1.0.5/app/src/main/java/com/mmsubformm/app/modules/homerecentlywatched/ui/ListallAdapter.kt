package com.mmsubformm.app.modules.homerecentlywatched.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mmsubformm.app.R
import com.mmsubformm.app.databinding.RowListall1Binding
import com.mmsubformm.app.modules.homerecentlywatched.`data`.model.Listall1RowModel
import kotlin.Int
import kotlin.collections.List

class ListallAdapter(
  var list: List<Listall1RowModel>
) : RecyclerView.Adapter<ListallAdapter.RowListall1VH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowListall1VH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_listall1,parent,false)
    return RowListall1VH(view)
  }

  override fun onBindViewHolder(holder: RowListall1VH, position: Int) {
    val listall1RowModel = Listall1RowModel()
    // TODO uncomment following line after integration with data source
    // val listall1RowModel = list[position]
    holder.binding.listall1RowModel = listall1RowModel
  }

  override fun getItemCount(): Int = 5
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<Listall1RowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: Listall1RowModel
    ) {
    }
  }

  inner class RowListall1VH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowListall1Binding = RowListall1Binding.bind(itemView)
  }
}
