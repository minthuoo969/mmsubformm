package com.mmsubformm.app.modules.about.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class AboutModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtGenre: String? = MyApp.getInstance().resources.getString(R.string.lbl_genre)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguagetext: String? = MyApp.getInstance().resources.getString(R.string.lbl_language_text)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAdventureComedyOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_adventure_come)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.lbl_english)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtYear: String? = MyApp.getInstance().resources.getString(R.string.lbl_year2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCountry: String? = MyApp.getInstance().resources.getString(R.string.lbl_country)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtZipcode: String? = MyApp.getInstance().resources.getString(R.string.lbl_2019)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtUnitedStates: String? = MyApp.getInstance().resources.getString(R.string.lbl_united_states)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtActors: String? = MyApp.getInstance().resources.getString(R.string.lbl_actors)

)
