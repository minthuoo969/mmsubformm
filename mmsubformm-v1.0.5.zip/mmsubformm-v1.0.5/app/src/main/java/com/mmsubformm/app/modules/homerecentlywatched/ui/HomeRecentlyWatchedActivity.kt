package com.mmsubformm.app.modules.homerecentlywatched.ui

import android.net.Uri
import android.view.View
import androidx.activity.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseActivity
import com.mmsubformm.app.databinding.ActivityHomeRecentlyWatchedBinding
import com.mmsubformm.app.modules.homerecentlywatched.`data`.model.ImageSliderSliderrectangletenModel
import com.mmsubformm.app.modules.homerecentlywatched.`data`.model.Listall1RowModel
import com.mmsubformm.app.modules.homerecentlywatched.`data`.model.Listrectangle2RowModel
import com.mmsubformm.app.modules.homerecentlywatched.`data`.model.ListrectanglesixRowModel
import com.mmsubformm.app.modules.homerecentlywatched.`data`.viewmodel.HomeRecentlyWatchedVM
import kotlin.Int
import kotlin.String
import kotlin.Unit
import kotlin.collections.ArrayList

class HomeRecentlyWatchedActivity :
    BaseActivity<ActivityHomeRecentlyWatchedBinding>(R.layout.activity_home_recently_watched) {
  private val imageUri: Uri =
      Uri.parse("android.resource://com.mmsubformm.app/drawable/img_image6_297x375")


  private val imageSliderSliderrectangletenItems: ArrayList<ImageSliderSliderrectangletenModel> =
      arrayListOf(ImageSliderSliderrectangletenModel(imageImageSix =
  imageUri.toString()),ImageSliderSliderrectangletenModel(imageImageSix =
  imageUri.toString()))


  private val viewModel: HomeRecentlyWatchedVM by viewModels<HomeRecentlyWatchedVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val sliderrectangletenAdapter =
    SliderrectangletenAdapter(imageSliderSliderrectangletenItems,true)
    binding.imageSliderSliderrectangleten.adapter = sliderrectangletenAdapter
    val listrectanglesixAdapter =
    ListrectanglesixAdapter(viewModel.listrectanglesixList.value?:mutableListOf())
    binding.recyclerListrectanglesix.adapter = listrectanglesixAdapter
    listrectanglesixAdapter.setOnItemClickListener(
    object : ListrectanglesixAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListrectanglesixRowModel) {
        onClickRecyclerListrectanglesix(view, position, item)
      }
    }
    )
    viewModel.listrectanglesixList.observe(this) {
      listrectanglesixAdapter.updateData(it)
    }
    val listallAdapter = ListallAdapter(viewModel.listallList.value?:mutableListOf())
    binding.recyclerListall.adapter = listallAdapter
    listallAdapter.setOnItemClickListener(
    object : ListallAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : Listall1RowModel) {
        onClickRecyclerListall(view, position, item)
      }
    }
    )
    viewModel.listallList.observe(this) {
      listallAdapter.updateData(it)
    }
    val listrectangleAdapter =
    ListrectangleAdapter(viewModel.listrectangleList.value?:mutableListOf())
    binding.recyclerListrectangle.adapter = listrectangleAdapter
    listrectangleAdapter.setOnItemClickListener(
    object : ListrectangleAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : Listrectangle2RowModel) {
        onClickRecyclerListrectangle(view, position, item)
      }
    }
    )
    viewModel.listrectangleList.observe(this) {
      listrectangleAdapter.updateData(it)
    }
    binding.homeRecentlyWatchedVM = viewModel
  }

  override fun onPause(): Unit {
    binding.imageSliderSliderrectangleten.pauseAutoScroll()
    super.onPause()
  }

  override fun onResume(): Unit {
    super.onResume()
    binding.imageSliderSliderrectangleten.resumeAutoScroll()
  }

  override fun setUpClicks(): Unit {
  }

  fun onClickRecyclerListrectanglesix(
    view: View,
    position: Int,
    item: ListrectanglesixRowModel
  ): Unit {
    when(view.id) {
    }
  }

  fun onClickRecyclerListall(
    view: View,
    position: Int,
    item: Listall1RowModel
  ): Unit {
    when(view.id) {
    }
  }

  fun onClickRecyclerListrectangle(
    view: View,
    position: Int,
    item: Listrectangle2RowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "HOME_RECENTLY_WATCHED_ACTIVITY"

  }
}
