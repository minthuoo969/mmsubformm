package com.mmsubformm.app.modules.downloadmoviepopup.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmsubformm.app.modules.downloadmoviepopup.`data`.model.DownloadMoviePopUpModel
import org.koin.core.KoinComponent

class DownloadMoviePopUpVM : ViewModel(), KoinComponent {
  val downloadMoviePopUpModel: MutableLiveData<DownloadMoviePopUpModel> =
      MutableLiveData(DownloadMoviePopUpModel())

  var navArguments: Bundle? = null
}
