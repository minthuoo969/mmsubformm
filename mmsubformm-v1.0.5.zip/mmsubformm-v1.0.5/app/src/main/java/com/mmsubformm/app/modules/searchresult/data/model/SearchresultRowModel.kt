package com.mmsubformm.app.modules.searchresult.`data`.model

class SearchresultRowModel()
