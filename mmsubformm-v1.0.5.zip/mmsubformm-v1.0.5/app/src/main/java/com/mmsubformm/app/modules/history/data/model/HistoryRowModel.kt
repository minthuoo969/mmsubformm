package com.mmsubformm.app.modules.history.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class HistoryRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtMysteryofMuye: String? =
      MyApp.getInstance().resources.getString(R.string.msg_mystery_of_muye)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtActionAdventureOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_action_adventu)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt20532: String? = MyApp.getInstance().resources.getString(R.string.lbl_2_05_32)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFilesize: String? = MyApp.getInstance().resources.getString(R.string.lbl_1_2gb)

)
