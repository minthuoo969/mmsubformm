package com.mmsubformm.app.modules.categorycomedy.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmsubformm.app.modules.categorycomedy.`data`.model.CategoryComedyModel
import com.mmsubformm.app.modules.categorycomedy.`data`.model.GridrectangleRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class CategoryComedyVM : ViewModel(), KoinComponent {
  val categoryComedyModel: MutableLiveData<CategoryComedyModel> =
      MutableLiveData(CategoryComedyModel())

  var navArguments: Bundle? = null

  val gridrectangleList: MutableLiveData<MutableList<GridrectangleRowModel>> =
      MutableLiveData(mutableListOf())
}
