package com.mmsubformm.app.modules.homerecentlywatched.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmsubformm.app.modules.homerecentlywatched.`data`.model.HomeRecentlyWatchedModel
import com.mmsubformm.app.modules.homerecentlywatched.`data`.model.Listall1RowModel
import com.mmsubformm.app.modules.homerecentlywatched.`data`.model.Listrectangle2RowModel
import com.mmsubformm.app.modules.homerecentlywatched.`data`.model.ListrectanglesixRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class HomeRecentlyWatchedVM : ViewModel(), KoinComponent {
  val homeRecentlyWatchedModel: MutableLiveData<HomeRecentlyWatchedModel> =
      MutableLiveData(HomeRecentlyWatchedModel())

  var navArguments: Bundle? = null

  val listrectanglesixList: MutableLiveData<MutableList<ListrectanglesixRowModel>> =
      MutableLiveData(mutableListOf())

  val listallList: MutableLiveData<MutableList<Listall1RowModel>> = MutableLiveData(mutableListOf())

  val listrectangleList: MutableLiveData<MutableList<Listrectangle2RowModel>> =
      MutableLiveData(mutableListOf())
}
