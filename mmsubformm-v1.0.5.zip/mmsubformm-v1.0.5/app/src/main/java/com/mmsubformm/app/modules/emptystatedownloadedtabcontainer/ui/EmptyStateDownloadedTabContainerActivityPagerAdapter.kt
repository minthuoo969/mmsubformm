package com.mmsubformm.app.modules.emptystatedownloadedtabcontainer.ui

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import com.mmsubformm.app.modules.emptystatedownloaded.ui.EmptyStateDownloadedFragment
import com.mmsubformm.app.modules.emptystatedownloading.ui.EmptyStateDownloadingFragment
import kotlin.Int
import kotlin.String
import kotlin.collections.List

class EmptyStateDownloadedTabContainerActivityPagerAdapter(
    val fragmentManager: FragmentManager,
    val lifecycle: Lifecycle
) : FragmentStateAdapter(fragmentManager, lifecycle) {
    override fun getItemCount(): Int = viewPages.size

    override fun createFragment(position: Int): Fragment = viewPages[position]

    companion object AdapterConstant {
        val title: List<String> =
                listOf(MyApp.getInstance().resources.getString(R.string.lbl_downloaded),MyApp.getInstance().resources.getString(R.string.lbl_downloading))

        val viewPages: List<Fragment> =
                listOf(EmptyStateDownloadedFragment(),EmptyStateDownloadingFragment())

    }
}
