package com.mmsubformm.app.modules.language.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class LanguageRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtCountryname: String? = MyApp.getInstance().resources.getString(R.string.lbl_england)

)
