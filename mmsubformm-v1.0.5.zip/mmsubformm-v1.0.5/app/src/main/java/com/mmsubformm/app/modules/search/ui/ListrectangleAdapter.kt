package com.mmsubformm.app.modules.search.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mmsubformm.app.R
import com.mmsubformm.app.databinding.RowListrectangle1Binding
import com.mmsubformm.app.modules.search.`data`.model.Listrectangle1RowModel
import kotlin.Int
import kotlin.collections.List

class ListrectangleAdapter(
  var list: List<Listrectangle1RowModel>
) : RecyclerView.Adapter<ListrectangleAdapter.RowListrectangle1VH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowListrectangle1VH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_listrectangle1,parent,false)
    return RowListrectangle1VH(view)
  }

  override fun onBindViewHolder(holder: RowListrectangle1VH, position: Int) {
    val listrectangle1RowModel = Listrectangle1RowModel()
    // TODO uncomment following line after integration with data source
    // val listrectangle1RowModel = list[position]
    holder.binding.listrectangle1RowModel = listrectangle1RowModel
  }

  override fun getItemCount(): Int = 4
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<Listrectangle1RowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: Listrectangle1RowModel
    ) {
    }
  }

  inner class RowListrectangle1VH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowListrectangle1Binding = RowListrectangle1Binding.bind(itemView)
  }
}
