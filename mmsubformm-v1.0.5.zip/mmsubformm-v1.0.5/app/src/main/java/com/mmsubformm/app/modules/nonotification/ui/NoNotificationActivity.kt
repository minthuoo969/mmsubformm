package com.mmsubformm.app.modules.nonotification.ui

import androidx.activity.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseActivity
import com.mmsubformm.app.databinding.ActivityNoNotificationBinding
import com.mmsubformm.app.modules.nonotification.`data`.viewmodel.NoNotificationVM
import kotlin.String
import kotlin.Unit

class NoNotificationActivity :
    BaseActivity<ActivityNoNotificationBinding>(R.layout.activity_no_notification) {
  private val viewModel: NoNotificationVM by viewModels<NoNotificationVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.noNotificationVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "NO_NOTIFICATION_ACTIVITY"

  }
}
