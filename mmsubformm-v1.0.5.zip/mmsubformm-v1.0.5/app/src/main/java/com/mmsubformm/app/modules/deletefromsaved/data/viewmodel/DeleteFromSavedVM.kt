package com.mmsubformm.app.modules.deletefromsaved.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmsubformm.app.modules.deletefromsaved.`data`.model.DeleteFromSavedModel
import org.koin.core.KoinComponent

class DeleteFromSavedVM : ViewModel(), KoinComponent {
  val deleteFromSavedModel: MutableLiveData<DeleteFromSavedModel> =
      MutableLiveData(DeleteFromSavedModel())

  var navArguments: Bundle? = null
}
