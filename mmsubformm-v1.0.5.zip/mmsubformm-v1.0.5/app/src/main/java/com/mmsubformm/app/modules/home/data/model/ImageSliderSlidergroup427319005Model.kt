package com.mmsubformm.app.modules.home.`data`.model

import kotlin.String

data class ImageSliderSlidergroup427319005Model(
  /**
   * TODO Replace with dynamic value
   */
  var imageImageSix: String? = ""

)
