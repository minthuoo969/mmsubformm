package com.mmsubformm.app.modules.chooseplan.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class ChooseplanRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtType: String? = MyApp.getInstance().resources.getString(R.string.lbl_weekly)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtIncludingtaxandOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_including_tax_a)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPrice: String? = MyApp.getInstance().resources.getString(R.string.lbl_50_week)

)
