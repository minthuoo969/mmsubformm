package com.mmsubformm.app.modules.emptystatedownloaded.ui

import androidx.fragment.app.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseFragment
import com.mmsubformm.app.databinding.FragmentEmptyStateDownloadedBinding
import com.mmsubformm.app.modules.emptystatedownloaded.`data`.viewmodel.EmptyStateDownloadedVM
import kotlin.String
import kotlin.Unit

class EmptyStateDownloadedFragment :
    BaseFragment<FragmentEmptyStateDownloadedBinding>(R.layout.fragment_empty_state_downloaded) {
  private val viewModel: EmptyStateDownloadedVM by viewModels<EmptyStateDownloadedVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    binding.emptyStateDownloadedVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "EMPTY_STATE_DOWNLOADED_FRAGMENT"

  }
}
