package com.mmsubformm.app.modules.splash.`data`.model

class SplashModel()
