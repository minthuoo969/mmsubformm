package com.mmsubformm.app.modules.emptystatedownloadedtabcontainer.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmsubformm.app.modules.emptystatedownloadedtabcontainer.`data`.model.EmptyStateDownloadedTabContainerModel
import org.koin.core.KoinComponent

class EmptyStateDownloadedTabContainerVM : ViewModel(), KoinComponent {
  val emptyStateDownloadedTabContainerModel: MutableLiveData<EmptyStateDownloadedTabContainerModel>
      = MutableLiveData(EmptyStateDownloadedTabContainerModel())

  var navArguments: Bundle? = null
}
