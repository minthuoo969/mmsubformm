package com.mmsubformm.app.modules.editprofile.`data`.model

import kotlin.String

data class SpinnerGenderOneModel(
  val itemName: String
)
