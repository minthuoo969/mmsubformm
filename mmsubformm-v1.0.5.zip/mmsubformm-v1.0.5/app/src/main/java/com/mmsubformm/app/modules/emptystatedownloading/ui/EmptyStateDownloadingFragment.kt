package com.mmsubformm.app.modules.emptystatedownloading.ui

import androidx.fragment.app.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseFragment
import com.mmsubformm.app.databinding.FragmentEmptyStateDownloadingBinding
import com.mmsubformm.app.modules.emptystatedownloading.`data`.viewmodel.EmptyStateDownloadingVM
import kotlin.String
import kotlin.Unit

class EmptyStateDownloadingFragment :
    BaseFragment<FragmentEmptyStateDownloadingBinding>(R.layout.fragment_empty_state_downloading) {
  private val viewModel: EmptyStateDownloadingVM by viewModels<EmptyStateDownloadingVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    binding.emptyStateDownloadingVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "EMPTY_STATE_DOWNLOADING_FRAGMENT"

  }
}
