package com.mmsubformm.app.modules.searchresult.ui

import android.view.View
import androidx.activity.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseActivity
import com.mmsubformm.app.databinding.ActivitySearchResultBinding
import com.mmsubformm.app.modules.notfound.ui.NotFoundActivity
import com.mmsubformm.app.modules.searchresult.`data`.model.SearchresultRowModel
import com.mmsubformm.app.modules.searchresult.`data`.viewmodel.SearchResultVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class SearchResultActivity :
    BaseActivity<ActivitySearchResultBinding>(R.layout.activity_search_result) {
  private val viewModel: SearchResultVM by viewModels<SearchResultVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val searchresultAdapter =
    SearchresultAdapter(viewModel.searchresultList.value?:mutableListOf())
    binding.recyclerSearchresult.adapter = searchresultAdapter
    searchresultAdapter.setOnItemClickListener(
    object : SearchresultAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : SearchresultRowModel) {
        onClickRecyclerSearchresult(view, position, item)
      }
    }
    )
    viewModel.searchresultList.observe(this) {
      searchresultAdapter.updateData(it)
    }
    binding.searchResultVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.searchViewSearch.setOnClickListener {
      val destIntent = NotFoundActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  fun onClickRecyclerSearchresult(
    view: View,
    position: Int,
    item: SearchresultRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "SEARCH_RESULT_ACTIVITY"

  }
}
