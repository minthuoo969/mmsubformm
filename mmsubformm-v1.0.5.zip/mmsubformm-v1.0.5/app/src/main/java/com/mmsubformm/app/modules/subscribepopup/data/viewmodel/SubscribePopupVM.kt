package com.mmsubformm.app.modules.subscribepopup.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmsubformm.app.modules.subscribepopup.`data`.model.SubscribePopupModel
import org.koin.core.KoinComponent

class SubscribePopupVM : ViewModel(), KoinComponent {
  val subscribePopupModel: MutableLiveData<SubscribePopupModel> =
      MutableLiveData(SubscribePopupModel())

  var navArguments: Bundle? = null
}
