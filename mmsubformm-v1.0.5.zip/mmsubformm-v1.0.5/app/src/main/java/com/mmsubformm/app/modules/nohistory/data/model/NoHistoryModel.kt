package com.mmsubformm.app.modules.nohistory.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class NoHistoryModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtHistory: String? = MyApp.getInstance().resources.getString(R.string.lbl_history)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNoHistory: String? = MyApp.getInstance().resources.getString(R.string.lbl_no_history)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTherearecurrently: String? =
      MyApp.getInstance().resources.getString(R.string.msg_there_are_curre)

)
