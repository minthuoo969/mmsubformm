package com.mmsubformm.app.modules.selectsaved.ui

import android.view.View
import androidx.activity.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseActivity
import com.mmsubformm.app.databinding.ActivitySelectSavedBinding
import com.mmsubformm.app.modules.selectsaved.`data`.model.SelectsavedRowModel
import com.mmsubformm.app.modules.selectsaved.`data`.viewmodel.SelectSavedVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class SelectSavedActivity : BaseActivity<ActivitySelectSavedBinding>(R.layout.activity_select_saved)
    {
  private val viewModel: SelectSavedVM by viewModels<SelectSavedVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val selectsavedAdapter =
    SelectsavedAdapter(viewModel.selectsavedList.value?:mutableListOf())
    binding.recyclerSelectsaved.adapter = selectsavedAdapter
    selectsavedAdapter.setOnItemClickListener(
    object : SelectsavedAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : SelectsavedRowModel) {
        onClickRecyclerSelectsaved(view, position, item)
      }
    }
    )
    viewModel.selectsavedList.observe(this) {
      selectsavedAdapter.updateData(it)
    }
    binding.selectSavedVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  fun onClickRecyclerSelectsaved(
    view: View,
    position: Int,
    item: SelectsavedRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "SELECT_SAVED_ACTIVITY"

  }
}
