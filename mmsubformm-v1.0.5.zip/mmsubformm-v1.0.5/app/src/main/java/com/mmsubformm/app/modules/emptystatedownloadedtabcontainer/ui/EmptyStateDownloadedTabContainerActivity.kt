package com.mmsubformm.app.modules.emptystatedownloadedtabcontainer.ui

import androidx.activity.viewModels
import com.google.android.material.tabs.TabLayoutMediator
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseActivity
import com.mmsubformm.app.databinding.ActivityEmptyStateDownloadedTabContainerBinding
import com.mmsubformm.app.modules.emptystatedownloadedtabcontainer.`data`.viewmodel.EmptyStateDownloadedTabContainerVM
import kotlin.String
import kotlin.Unit

class EmptyStateDownloadedTabContainerActivity :
    BaseActivity<ActivityEmptyStateDownloadedTabContainerBinding>(R.layout.activity_empty_state_downloaded_tab_container)
    {
  private val viewModel: EmptyStateDownloadedTabContainerVM by
      viewModels<EmptyStateDownloadedTabContainerVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.emptyStateDownloadedTabContainerVM = viewModel
    val adapter =
    EmptyStateDownloadedTabContainerActivityPagerAdapter(supportFragmentManager,lifecycle)
    binding.viewPagerTabbarview.adapter = adapter
    TabLayoutMediator(binding.tabLayoutTab,binding.viewPagerTabbarview) { tab, position ->
      tab.text = EmptyStateDownloadedTabContainerActivityPagerAdapter.title[position]
      }.attach()
    }

    override fun setUpClicks(): Unit {
    }

    companion object {
      const val TAG: String = "EMPTY_STATE_DOWNLOADED_TAB_CONTAINER_ACTIVITY"

    }
  }
