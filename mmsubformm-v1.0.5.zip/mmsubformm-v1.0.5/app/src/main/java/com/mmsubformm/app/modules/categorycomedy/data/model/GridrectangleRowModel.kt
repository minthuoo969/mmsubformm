package com.mmsubformm.app.modules.categorycomedy.`data`.model

class GridrectangleRowModel()
