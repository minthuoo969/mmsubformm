package com.mmsubformm.app.modules.searchhelp.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.widget.SearchView
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseActivity
import com.mmsubformm.app.databinding.ActivitySearchHelpBinding
import com.mmsubformm.app.modules.searchhelp.`data`.viewmodel.SearchHelpVM
import kotlin.Boolean
import kotlin.String
import kotlin.Unit

class SearchHelpActivity : BaseActivity<ActivitySearchHelpBinding>(R.layout.activity_search_help) {
  private val viewModel: SearchHelpVM by viewModels<SearchHelpVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.searchHelpVM = viewModel
    setUpSearchViewGroupListener()
  }

  override fun setUpClicks(): Unit {
    binding.btnArrowleft.setOnClickListener {
      finish()
    }
  }

  private fun setUpSearchViewGroupListener(): Unit {
    binding.searchViewGroup.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
      override fun onQueryTextSubmit(p0 : String) : Boolean {
        // Performs search when user hit
        // the search button on the keyboard
        return false
      }
      override fun onQueryTextChange(p0 : String) : Boolean {
        // Start filtering the list as user
        // start entering the characters
        return false
      }
      })
    }

    companion object {
      const val TAG: String = "SEARCH_HELP_ACTIVITY"


      fun getIntent(context: Context, bundle: Bundle?): Intent {
        val destIntent = Intent(context, SearchHelpActivity::class.java)
        destIntent.putExtra("bundle", bundle)
        return destIntent
      }
    }
  }
