package com.mmsubformm.app.modules.emptystatedownloaded.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmsubformm.app.modules.emptystatedownloaded.`data`.model.EmptyStateDownloadedModel
import org.koin.core.KoinComponent

class EmptyStateDownloadedVM : ViewModel(), KoinComponent {
  val emptyStateDownloadedModel: MutableLiveData<EmptyStateDownloadedModel> =
      MutableLiveData(EmptyStateDownloadedModel())

  var navArguments: Bundle? = null
}
