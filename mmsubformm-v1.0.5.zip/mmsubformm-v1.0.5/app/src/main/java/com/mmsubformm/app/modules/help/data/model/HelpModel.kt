package com.mmsubformm.app.modules.help.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class HelpModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtHelp: String? = MyApp.getInstance().resources.getString(R.string.lbl_help)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTopanswers: String? = MyApp.getInstance().resources.getString(R.string.lbl_top_answers)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHowtocontactcustomer: String? =
      MyApp.getInstance().resources.getString(R.string.msg_how_to_contact)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHowtounsubscribe: String? =
      MyApp.getInstance().resources.getString(R.string.msg_how_to_unsubscr)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHowtosubscribe: String? =
      MyApp.getInstance().resources.getString(R.string.msg_how_to_subscrib)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCantwatchmovistart: String? =
      MyApp.getInstance().resources.getString(R.string.msg_can_t_watch_mov)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWhatismovistartOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_what_is_movista)

)
