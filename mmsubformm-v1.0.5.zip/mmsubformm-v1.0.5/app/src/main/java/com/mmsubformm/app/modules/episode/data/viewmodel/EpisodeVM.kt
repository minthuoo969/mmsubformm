package com.mmsubformm.app.modules.episode.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmsubformm.app.modules.episode.`data`.model.EpisodeModel
import org.koin.core.KoinComponent

class EpisodeVM : ViewModel(), KoinComponent {
  val episodeModel: MutableLiveData<EpisodeModel> = MutableLiveData(EpisodeModel())

  var navArguments: Bundle? = null
}
