package com.mmsubformm.app.modules.homerecentlywatched.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mmsubformm.app.R
import com.mmsubformm.app.databinding.RowListrectangle2Binding
import com.mmsubformm.app.modules.homerecentlywatched.`data`.model.Listrectangle2RowModel
import kotlin.Int
import kotlin.collections.List

class ListrectangleAdapter(
  var list: List<Listrectangle2RowModel>
) : RecyclerView.Adapter<ListrectangleAdapter.RowListrectangle2VH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowListrectangle2VH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_listrectangle2,parent,false)
    return RowListrectangle2VH(view)
  }

  override fun onBindViewHolder(holder: RowListrectangle2VH, position: Int) {
    val listrectangle2RowModel = Listrectangle2RowModel()
    // TODO uncomment following line after integration with data source
    // val listrectangle2RowModel = list[position]
    holder.binding.listrectangle2RowModel = listrectangle2RowModel
  }

  override fun getItemCount(): Int = 3
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<Listrectangle2RowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: Listrectangle2RowModel
    ) {
    }
  }

  inner class RowListrectangle2VH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowListrectangle2Binding = RowListrectangle2Binding.bind(itemView)
  }
}
