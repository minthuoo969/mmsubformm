package com.mmsubformm.app.modules.home.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class HomeModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtCatagories: String? = MyApp.getInstance().resources.getString(R.string.lbl_catagories)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMostPopular: String? = MyApp.getInstance().resources.getString(R.string.lbl_most_popular)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSeeall: String? = MyApp.getInstance().resources.getString(R.string.lbl_see_all)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLatestMovies: String? = MyApp.getInstance().resources.getString(R.string.lbl_latest_movies)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSeeallOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_see_all)

)
