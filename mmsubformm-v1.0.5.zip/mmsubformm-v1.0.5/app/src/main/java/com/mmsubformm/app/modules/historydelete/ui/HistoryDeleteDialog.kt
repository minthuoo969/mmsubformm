package com.mmsubformm.app.modules.historydelete.ui

import android.content.Context
import androidx.fragment.app.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseDialogFragment
import com.mmsubformm.app.databinding.DialogHistoryDeleteBinding
import com.mmsubformm.app.modules.historydelete.`data`.viewmodel.HistoryDeleteVM
import kotlin.String
import kotlin.Unit

class HistoryDeleteDialog :
    BaseDialogFragment<DialogHistoryDeleteBinding>(R.layout.dialog_history_delete) {
  private val viewModel: HistoryDeleteVM by viewModels<HistoryDeleteVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    binding.historyDeleteVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "HISTORY_DELETE_DIALOG"

  }
}
