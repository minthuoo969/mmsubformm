package com.mmsubformm.app.modules.downloading.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mmsubformm.app.R
import com.mmsubformm.app.databinding.RowDownloadingBinding
import com.mmsubformm.app.modules.downloading.`data`.model.DownloadingRowModel
import kotlin.Int
import kotlin.collections.List

class DownloadingAdapter(
  var list: List<DownloadingRowModel>
) : RecyclerView.Adapter<DownloadingAdapter.RowDownloadingVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowDownloadingVH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_downloading,parent,false)
    return RowDownloadingVH(view)
  }

  override fun onBindViewHolder(holder: RowDownloadingVH, position: Int) {
    val downloadingRowModel = DownloadingRowModel()
    // TODO uncomment following line after integration with data source
    // val downloadingRowModel = list[position]
    holder.binding.downloadingRowModel = downloadingRowModel
  }

  override fun getItemCount(): Int = 2
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<DownloadingRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: DownloadingRowModel
    ) {
    }
  }

  inner class RowDownloadingVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowDownloadingBinding = RowDownloadingBinding.bind(itemView)
  }
}
