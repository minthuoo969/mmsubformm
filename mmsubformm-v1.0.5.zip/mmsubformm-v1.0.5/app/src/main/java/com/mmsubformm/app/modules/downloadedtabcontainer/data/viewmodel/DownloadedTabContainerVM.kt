package com.mmsubformm.app.modules.downloadedtabcontainer.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmsubformm.app.modules.downloadedtabcontainer.`data`.model.DownloadedTabContainerModel
import org.koin.core.KoinComponent

class DownloadedTabContainerVM : ViewModel(), KoinComponent {
  val downloadedTabContainerModel: MutableLiveData<DownloadedTabContainerModel> =
      MutableLiveData(DownloadedTabContainerModel())

  var navArguments: Bundle? = null
}
