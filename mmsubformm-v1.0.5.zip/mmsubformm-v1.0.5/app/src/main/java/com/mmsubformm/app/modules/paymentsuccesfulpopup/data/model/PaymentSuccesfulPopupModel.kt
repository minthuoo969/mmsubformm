package com.mmsubformm.app.modules.paymentsuccesfulpopup.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class PaymentSuccesfulPopupModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtCongratsyourpackage: String? =
      MyApp.getInstance().resources.getString(R.string.msg_congrats_your_p)

)
