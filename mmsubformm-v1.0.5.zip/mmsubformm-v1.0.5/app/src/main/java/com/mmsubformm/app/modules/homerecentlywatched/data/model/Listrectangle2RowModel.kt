package com.mmsubformm.app.modules.homerecentlywatched.`data`.model

class Listrectangle2RowModel()
