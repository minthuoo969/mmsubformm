package com.mmsubformm.app.modules.searchhelp.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class SearchHelpModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtHelp: String? = MyApp.getInstance().resources.getString(R.string.lbl_help)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt4Answersfound: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_4_answers_found)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHowtousevoucherOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_how_to_use_vouc)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHowtounsubscribe: String? =
      MyApp.getInstance().resources.getString(R.string.msg_how_to_unsubscr)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHowtosubscribe: String? =
      MyApp.getInstance().resources.getString(R.string.msg_how_to_subscrib)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHowtocontactcustomer: String? =
      MyApp.getInstance().resources.getString(R.string.msg_how_to_contact)

)
