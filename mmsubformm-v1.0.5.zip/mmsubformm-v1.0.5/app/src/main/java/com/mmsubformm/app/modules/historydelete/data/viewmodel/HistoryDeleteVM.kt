package com.mmsubformm.app.modules.historydelete.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmsubformm.app.modules.historydelete.`data`.model.HistoryDeleteModel
import org.koin.core.KoinComponent

class HistoryDeleteVM : ViewModel(), KoinComponent {
  val historyDeleteModel: MutableLiveData<HistoryDeleteModel> =
      MutableLiveData(HistoryDeleteModel())

  var navArguments: Bundle? = null
}
