package com.mmsubformm.app.modules.help.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseActivity
import com.mmsubformm.app.databinding.ActivityHelpBinding
import com.mmsubformm.app.modules.help.`data`.viewmodel.HelpVM
import com.mmsubformm.app.modules.searchhelp.ui.SearchHelpActivity
import kotlin.String
import kotlin.Unit

class HelpActivity : BaseActivity<ActivityHelpBinding>(R.layout.activity_help) {
  private val viewModel: HelpVM by viewModels<HelpVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.helpVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.searchViewGroup.setOnClickListener {
      val destIntent = SearchHelpActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.btnArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "HELP_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, HelpActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
