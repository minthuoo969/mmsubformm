package com.mmsubformm.app.modules.categorycomedy.ui

import android.view.View
import androidx.activity.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseActivity
import com.mmsubformm.app.databinding.ActivityCategoryComedyBinding
import com.mmsubformm.app.modules.categorycomedy.`data`.model.GridrectangleRowModel
import com.mmsubformm.app.modules.categorycomedy.`data`.viewmodel.CategoryComedyVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class CategoryComedyActivity :
    BaseActivity<ActivityCategoryComedyBinding>(R.layout.activity_category_comedy) {
  private val viewModel: CategoryComedyVM by viewModels<CategoryComedyVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val gridrectangleAdapter =
    GridrectangleAdapter(viewModel.gridrectangleList.value?:mutableListOf())
    binding.recyclerGridrectangle.adapter = gridrectangleAdapter
    gridrectangleAdapter.setOnItemClickListener(
    object : GridrectangleAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : GridrectangleRowModel) {
        onClickRecyclerGridrectangle(view, position, item)
      }
    }
    )
    viewModel.gridrectangleList.observe(this) {
      gridrectangleAdapter.updateData(it)
    }
    binding.categoryComedyVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnArrowleft.setOnClickListener {
      finish()
    }
  }

  fun onClickRecyclerGridrectangle(
    view: View,
    position: Int,
    item: GridrectangleRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "CATEGORY_COMEDY_ACTIVITY"

  }
}
