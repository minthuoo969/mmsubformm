package com.mmsubformm.app.modules.paymentsuccesfulpopup.ui

import android.content.Context
import androidx.fragment.app.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseDialogFragment
import com.mmsubformm.app.databinding.DialogPaymentSuccesfulPopupBinding
import com.mmsubformm.app.modules.paymentsuccesfulpopup.`data`.viewmodel.PaymentSuccesfulPopupVM
import kotlin.String
import kotlin.Unit

class PaymentSuccesfulPopupDialog :
    BaseDialogFragment<DialogPaymentSuccesfulPopupBinding>(R.layout.dialog_payment_succesful_popup)
    {
  private val viewModel: PaymentSuccesfulPopupVM by viewModels<PaymentSuccesfulPopupVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    binding.paymentSuccesfulPopupVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "PAYMENT_SUCCESFUL_POPUP_DIALOG"

  }
}
