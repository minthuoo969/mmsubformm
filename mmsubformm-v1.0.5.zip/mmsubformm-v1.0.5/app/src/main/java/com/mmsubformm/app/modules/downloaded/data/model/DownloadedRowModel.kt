package com.mmsubformm.app.modules.downloaded.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class DownloadedRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtTitle: String? = MyApp.getInstance().resources.getString(R.string.msg_captain_america)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGenre: String? = MyApp.getInstance().resources.getString(R.string.msg_action_adventu)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRuntime: String? = MyApp.getInstance().resources.getString(R.string.lbl_2_05_32)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFilesize: String? = MyApp.getInstance().resources.getString(R.string.lbl_1_2gb)

)
