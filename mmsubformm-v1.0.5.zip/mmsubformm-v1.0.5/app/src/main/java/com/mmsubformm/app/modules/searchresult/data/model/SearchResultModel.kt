package com.mmsubformm.app.modules.searchresult.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class SearchResultModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtResultsforcomedy: String? =
      MyApp.getInstance().resources.getString(R.string.msg_results_for_co)

)
