package com.mmsubformm.app.modules.episodetabcontainer.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.google.android.material.tabs.TabLayoutMediator
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseActivity
import com.mmsubformm.app.databinding.ActivityEpisodeTabContainerBinding
import com.mmsubformm.app.modules.episodetabcontainer.`data`.viewmodel.EpisodeTabContainerVM
import kotlin.String
import kotlin.Unit

class EpisodeTabContainerActivity :
    BaseActivity<ActivityEpisodeTabContainerBinding>(R.layout.activity_episode_tab_container) {
  private val viewModel: EpisodeTabContainerVM by viewModels<EpisodeTabContainerVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.episodeTabContainerVM = viewModel
    val adapter = EpisodeTabContainerActivityPagerAdapter(supportFragmentManager,lifecycle)
    binding.viewPagerTabbarview.adapter = adapter
    TabLayoutMediator(binding.tabLayoutEpisode,binding.viewPagerTabbarview) { tab, position ->
      tab.text = EpisodeTabContainerActivityPagerAdapter.title[position]
      }.attach()
    }

    override fun setUpClicks(): Unit {
      binding.btnArrowleft.setOnClickListener {
        finish()
      }
    }

    companion object {
      const val TAG: String = "EPISODE_TAB_CONTAINER_ACTIVITY"


      fun getIntent(context: Context, bundle: Bundle?): Intent {
        val destIntent = Intent(context, EpisodeTabContainerActivity::class.java)
        destIntent.putExtra("bundle", bundle)
        return destIntent
      }
    }
  }
