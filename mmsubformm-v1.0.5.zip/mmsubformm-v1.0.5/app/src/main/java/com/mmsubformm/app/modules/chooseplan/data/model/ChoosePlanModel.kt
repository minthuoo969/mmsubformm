package com.mmsubformm.app.modules.chooseplan.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class ChoosePlanModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtChooseyourfavorite: String? =
      MyApp.getInstance().resources.getString(R.string.msg_choose_your_fav)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtVoucher: String? = MyApp.getInstance().resources.getString(R.string.lbl_voucher)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etHaveavouchercodeValue: String? = null
)
