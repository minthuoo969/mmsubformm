package com.mmsubformm.app.modules.profile.ui

import androidx.fragment.app.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseFragment
import com.mmsubformm.app.databinding.FragmentProfileBinding
import com.mmsubformm.app.modules.chooseplan.ui.ChoosePlanActivity
import com.mmsubformm.app.modules.editprofile.ui.EditProfileActivity
import com.mmsubformm.app.modules.help.ui.HelpActivity
import com.mmsubformm.app.modules.history.ui.HistoryActivity
import com.mmsubformm.app.modules.notification.ui.NotificationActivity
import com.mmsubformm.app.modules.profile.`data`.viewmodel.ProfileVM
import com.mmsubformm.app.modules.setting.ui.SettingActivity
import kotlin.String
import kotlin.Unit

class ProfileFragment : BaseFragment<FragmentProfileBinding>(R.layout.fragment_profile) {
  private val viewModel: ProfileVM by viewModels<ProfileVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    binding.profileVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.linearNotification.setOnClickListener {
      val destIntent = NotificationActivity.getIntent(requireActivity(), null)
      startActivity(destIntent)
      requireActivity().onBackPressed()
    }
    binding.linearMySubscription.setOnClickListener {
      val destIntent = ChoosePlanActivity.getIntent(requireActivity(), null)
      startActivity(destIntent)
      requireActivity().onBackPressed()
    }
    binding.linearHelp.setOnClickListener {
      val destIntent = HelpActivity.getIntent(requireActivity(), null)
      startActivity(destIntent)
      requireActivity().onBackPressed()
    }
    binding.linearHistory.setOnClickListener {
      val destIntent = HistoryActivity.getIntent(requireActivity(), null)
      startActivity(destIntent)
      requireActivity().onBackPressed()
    }
    binding.linearRowuser.setOnClickListener {
      val destIntent = EditProfileActivity.getIntent(requireActivity(), null)
      startActivity(destIntent)
      requireActivity().onBackPressed()
    }
    binding.linearSetting.setOnClickListener {
      val destIntent = SettingActivity.getIntent(requireActivity(), null)
      startActivity(destIntent)
      requireActivity().onBackPressed()
    }
  }

  companion object {
    const val TAG: String = "PROFILE_FRAGMENT"

  }
}
