package com.mmsubformm.app.modules.downloaded.`data`.model

class DownloadedModel()
