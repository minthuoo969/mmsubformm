package com.mmsubformm.app.modules.search.ui

import android.view.View
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseFragment
import com.mmsubformm.app.databinding.FragmentSearchBinding
import com.mmsubformm.app.modules.search.`data`.model.ListRowModel
import com.mmsubformm.app.modules.search.`data`.model.Listrectangle1RowModel
import com.mmsubformm.app.modules.search.`data`.viewmodel.SearchVM
import kotlin.Boolean
import kotlin.Int
import kotlin.String
import kotlin.Unit

class SearchFragment : BaseFragment<FragmentSearchBinding>(R.layout.fragment_search) {
  private val viewModel: SearchVM by viewModels<SearchVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    val listrectangleAdapter =
    ListrectangleAdapter(viewModel.listrectangleList.value?:mutableListOf())
    binding.recyclerListrectangle.adapter = listrectangleAdapter
    listrectangleAdapter.setOnItemClickListener(
    object : ListrectangleAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : Listrectangle1RowModel) {
        onClickRecyclerListrectangle(view, position, item)
      }
    }
    )
    viewModel.listrectangleList.observe(requireActivity()) {
      listrectangleAdapter.updateData(it)
    }
    val listAdapter = ListAdapter(viewModel.listList.value?:mutableListOf())
    binding.recyclerList.adapter = listAdapter
    listAdapter.setOnItemClickListener(
    object : ListAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListRowModel) {
        onClickRecyclerList(view, position, item)
      }
    }
    )
    viewModel.listList.observe(requireActivity()) {
      listAdapter.updateData(it)
    }
    binding.searchVM = viewModel
    setUpSearchViewSearchListener()
  }

  override fun setUpClicks(): Unit {
  }

  fun onClickRecyclerListrectangle(
    view: View,
    position: Int,
    item: Listrectangle1RowModel
  ): Unit {
    when(view.id) {
    }
  }

  fun onClickRecyclerList(
    view: View,
    position: Int,
    item: ListRowModel
  ): Unit {
    when(view.id) {
    }
  }

  private fun setUpSearchViewSearchListener(): Unit {
    binding.searchViewSearch.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
      override fun onQueryTextSubmit(p0 : String) : Boolean {
        // Performs search when user hit
        // the search button on the keyboard
        return false
      }
      override fun onQueryTextChange(p0 : String) : Boolean {
        // Start filtering the list as user
        // start entering the characters
        return false
      }
      })
    }

    companion object {
      const val TAG: String = "SEARCH_FRAGMENT"

    }
  }
