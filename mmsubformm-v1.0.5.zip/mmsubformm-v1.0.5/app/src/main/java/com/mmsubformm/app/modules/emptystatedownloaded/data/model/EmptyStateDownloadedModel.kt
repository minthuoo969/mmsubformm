package com.mmsubformm.app.modules.emptystatedownloaded.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class EmptyStateDownloadedModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtNovideosyet: String? = MyApp.getInstance().resources.getString(R.string.lbl_no_videos_yet)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLetsfindanddownload: String? =
      MyApp.getInstance().resources.getString(R.string.msg_let_s_find_and)

)
