package com.mmsubformm.app.modules.downloadmoviepopup.ui

import android.content.Context
import androidx.fragment.app.viewModels
import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.base.BaseDialogFragment
import com.mmsubformm.app.databinding.DialogDownloadMoviePopUpBinding
import com.mmsubformm.app.modules.downloadmoviepopup.`data`.viewmodel.DownloadMoviePopUpVM
import kotlin.String
import kotlin.Unit

class DownloadMoviePopUpDialog :
    BaseDialogFragment<DialogDownloadMoviePopUpBinding>(R.layout.dialog_download_movie_pop_up) {
  private val viewModel: DownloadMoviePopUpVM by viewModels<DownloadMoviePopUpVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    binding.downloadMoviePopUpVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "DOWNLOAD_MOVIE_POP_UP_DIALOG"

  }
}
