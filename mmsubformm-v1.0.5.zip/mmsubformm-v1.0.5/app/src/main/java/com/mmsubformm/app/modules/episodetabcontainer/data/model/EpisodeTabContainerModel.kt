package com.mmsubformm.app.modules.episodetabcontainer.`data`.model

import com.mmsubformm.app.R
import com.mmsubformm.app.appcomponents.di.MyApp
import kotlin.String

data class EpisodeTabContainerModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtDisneysAladdin: String? =
      MyApp.getInstance().resources.getString(R.string.msg_disney_s_aladdi2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtZipcode: String? = MyApp.getInstance().resources.getString(R.string.lbl_2019)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAdventureComedyOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_adventure_come2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDistance: String? = MyApp.getInstance().resources.getString(R.string.lbl_2h_8m)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDescription: String? =
      MyApp.getInstance().resources.getString(R.string.msg_aladdin_a_stre2)

)
